import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final TextEditingController _controller = TextEditingController();
  Map<String, dynamic>? _weatherData;

  Future<void> _fetchWeather() async {
    final String query = _controller.text;
    if (query.isEmpty) return;

    final String apiKey = '6e951e2e1f534e1580b172331241910'; // Your API key
    final String url =
        'http://api.weatherapi.com/v1/current.json?key=$apiKey&q=$query&aqi=no';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        setState(() {
          _weatherData = data; // Store the complete weather data
        });
      } else {
        setState(() {
          _weatherData = null; // Reset if error occurs
        });
      }
    } catch (e) {
      setState(() {
        _weatherData = null; // Reset if error occurs
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Weather App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter location',
                suffixIcon: IconButton(
                  icon: Icon(Icons.search),
                  onPressed: _fetchWeather,
                ),
              ),
            ),
            SizedBox(height: 20),
            if (_weatherData != null) ...[
              Text(
                '${_weatherData!['location']['name']}, ${_weatherData!['location']['region']}',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                'Temperature: ${_weatherData!['current']['temp_c']} °C',
                style: TextStyle(fontSize: 18),
              ),
              Text(
                'Condition: ${_weatherData!['current']['condition']['text']}',
                style: TextStyle(fontSize: 18),
              ),
              Text(
                'Humidity: ${_weatherData!['current']['humidity']}%',
                style: TextStyle(fontSize: 18),
              ),
              Text(
                'Wind Speed: ${_weatherData!['current']['wind_kph']} kph',
                style: TextStyle(fontSize: 18),
              ),
              Text(
                'Feels Like: ${_weatherData!['current']['feelslike_c']} °C',
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 10),
              Image.network(
                'https:${_weatherData!['current']['condition']['icon']}',
              ),
            ] else if (_weatherData == null) ...[
              Text(
                'No data available. Please try again.',
                style: TextStyle(color: Colors.red),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
