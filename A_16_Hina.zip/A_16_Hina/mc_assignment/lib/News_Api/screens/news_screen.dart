import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../widgets/category_drawer.dart';

class NewsScreen extends StatefulWidget {
  @override
  _NewsScreenState createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> articles = [];
  String selectedCategory = 'general';

  @override
  void initState() {
    super.initState();
    fetchArticles();
  }

  // Fetch articles and update the state
  Future<void> fetchArticles() async {
    try {
      final fetchedArticles = await apiService.fetchArticles(selectedCategory);
      setState(() {
        articles = fetchedArticles;
      });
    } catch (error) {
      print('Error fetching articles: $error');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Failed to load articles: $error'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('News App'),
      ),
      drawer: CategoryDrawer(
        onCategorySelected: (category) {
          setState(() {
            selectedCategory = category;
          });
          fetchArticles();
        },
      ),
      body: articles.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: articles.length,
        itemBuilder: (context, index) {
          final article = articles[index];

          // Safeguard against null or missing fields
          final title = article['title'] ?? 'No Title';
          final description = article['description'] ?? 'No description available.';
          final imageUrl = article['urlToImage'];
          final url = article['url'] ?? '';

          return ListTile(
            title: Text(title),
            subtitle: Text(description),
            leading: (imageUrl != null && imageUrl.isNotEmpty)
                ? Image.network(
              imageUrl,
              width: 100,
              fit: BoxFit.cover,
            )
                : Icon(Icons.image_not_supported), // Fallback icon if image is missing
            onTap: () {
              // Handle article tap (e.g., navigate to a web view or show the full article)
              print('Tapped on article: $title');
            },
          );
        },
      ),
    );
  }
}
